Instructions:

Install screensavers by double-clicking and following the instructions. 'NASA_HDEV' is the High-Definition Earth Viewing feed, and this is probably the one you want. It shows a live view of Earth from the ISS. Note that it is frequently down when changing cameras or when the ISS is on the dark side of the Earth, so if everything is black then wait a bit.
The 'NASA_ISS' screensaver is the ISS live-stream. It shows footage from the ISS, and is much more astronaut-focussed.

Credit for these screensavers goes to Vladimir Sobolev, who wrote the original code and hosted it at his site: http://sobolev.us/iss-hd-earth-viewing-experiment-screen-saver/
I merely edited it to remove the audio and add an additional version for the other NASA feed. If you want a version with NASA audio, check his one out.

If you want a version with a built-in map, see the instructions at http://richardwestenra.com/live-iss-screensaver/.

Cheers,
Richard Westenra